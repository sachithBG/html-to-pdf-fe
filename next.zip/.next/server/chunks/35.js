"use strict";exports.id=35,exports.ids=[35],exports.modules={31345:(t,e,r)=>{r.d(e,{A:()=>i});var a=r(64445),o=r(45512);let i=(0,a.A)((0,o.jsx)("path",{d:"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m-2 15-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8z"}),"CheckCircle")},60067:(t,e,r)=>{r.d(e,{A:()=>i});var a=r(64445),o=r(45512);let i=(0,a.A)((0,o.jsx)("path",{d:"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m1 15h-2v-2h2zm0-4h-2V7h2z"}),"Error")},9301:(t,e,r)=>{r.d(e,{A:()=>y});var a=r(58009),o=r(82281),i=r(29107),d=r(35884),l=r(55249),s=r(31137),n=r(88613);function p(t){return(0,n.Ay)("MuiFormGroup",t)}(0,s.A)("MuiFormGroup",["root","row","error"]);var c=r(49408),h=r(21110),m=r(45512);let g=t=>{let{classes:e,row:r,error:a}=t;return(0,i.A)({root:["root",r&&"row",a&&"error"]},p,e)},u=(0,d.Ay)("div",{name:"MuiFormGroup",slot:"Root",overridesResolver:(t,e)=>{let{ownerState:r}=t;return[e.root,r.row&&e.row]}})({display:"flex",flexDirection:"column",flexWrap:"wrap",variants:[{props:{row:!0},style:{flexDirection:"row"}}]}),y=a.forwardRef(function(t,e){let r=(0,l.b)({props:t,name:"MuiFormGroup"}),{className:a,row:i=!1,...d}=r,s=(0,c.A)(),n=(0,h.A)({props:r,muiFormControl:s,states:["error"]}),p={...r,row:i,error:n.error},y=g(p);return(0,m.jsx)(u,{className:(0,o.A)(y.root,a),ownerState:p,ref:e,...d})})},18969:(t,e,r)=>{r.d(e,{A:()=>k});var a=r(58009),o=r(82281),i=r(29107),d=r(58242),l=r(50178),s=r(68640),n=r(12877),p=r(35884),c=r(94880),h=r(55249),m=r(31137),g=r(88613);function u(t){return(0,g.Ay)("MuiSwitch",t)}let y=(0,m.A)("MuiSwitch",["root","edgeStart","edgeEnd","switchBase","colorPrimary","colorSecondary","sizeSmall","sizeMedium","checked","disabled","input","thumb","track"]);var x=r(45512);let f=t=>{let{classes:e,edge:r,size:a,color:o,checked:d,disabled:s}=t,n={root:["root",r&&`edge${(0,l.A)(r)}`,`size${(0,l.A)(a)}`],switchBase:["switchBase",`color${(0,l.A)(o)}`,d&&"checked",s&&"disabled"],thumb:["thumb"],track:["track"],input:["input"]},p=(0,i.A)(n,u,e);return{...e,...p}},v=(0,p.Ay)("span",{name:"MuiSwitch",slot:"Root",overridesResolver:(t,e)=>{let{ownerState:r}=t;return[e.root,r.edge&&e[`edge${(0,l.A)(r.edge)}`],e[`size${(0,l.A)(r.size)}`]]}})({display:"inline-flex",width:58,height:38,overflow:"hidden",padding:12,boxSizing:"border-box",position:"relative",flexShrink:0,zIndex:0,verticalAlign:"middle","@media print":{colorAdjust:"exact"},variants:[{props:{edge:"start"},style:{marginLeft:-8}},{props:{edge:"end"},style:{marginRight:-8}},{props:{size:"small"},style:{width:40,height:24,padding:7,[`& .${y.thumb}`]:{width:16,height:16},[`& .${y.switchBase}`]:{padding:4,[`&.${y.checked}`]:{transform:"translateX(16px)"}}}}]}),b=(0,p.Ay)(n.A,{name:"MuiSwitch",slot:"SwitchBase",overridesResolver:(t,e)=>{let{ownerState:r}=t;return[e.switchBase,{[`& .${y.input}`]:e.input},"default"!==r.color&&e[`color${(0,l.A)(r.color)}`]]}})((0,c.A)(({theme:t})=>({position:"absolute",top:0,left:0,zIndex:1,color:t.vars?t.vars.palette.Switch.defaultColor:`${"light"===t.palette.mode?t.palette.common.white:t.palette.grey[300]}`,transition:t.transitions.create(["left","transform"],{duration:t.transitions.duration.shortest}),[`&.${y.checked}`]:{transform:"translateX(20px)"},[`&.${y.disabled}`]:{color:t.vars?t.vars.palette.Switch.defaultDisabledColor:`${"light"===t.palette.mode?t.palette.grey[100]:t.palette.grey[600]}`},[`&.${y.checked} + .${y.track}`]:{opacity:.5},[`&.${y.disabled} + .${y.track}`]:{opacity:t.vars?t.vars.opacity.switchTrackDisabled:`${"light"===t.palette.mode?.12:.2}`},[`& .${y.input}`]:{left:"-100%",width:"300%"}})),(0,c.A)(({theme:t})=>({"&:hover":{backgroundColor:t.vars?`rgba(${t.vars.palette.action.activeChannel} / ${t.vars.palette.action.hoverOpacity})`:(0,d.X4)(t.palette.action.active,t.palette.action.hoverOpacity),"@media (hover: none)":{backgroundColor:"transparent"}},variants:[...Object.entries(t.palette).filter((0,s.A)(["light"])).map(([e])=>({props:{color:e},style:{[`&.${y.checked}`]:{color:(t.vars||t).palette[e].main,"&:hover":{backgroundColor:t.vars?`rgba(${t.vars.palette[e].mainChannel} / ${t.vars.palette.action.hoverOpacity})`:(0,d.X4)(t.palette[e].main,t.palette.action.hoverOpacity),"@media (hover: none)":{backgroundColor:"transparent"}},[`&.${y.disabled}`]:{color:t.vars?t.vars.palette.Switch[`${e}DisabledColor`]:`${"light"===t.palette.mode?(0,d.a)(t.palette[e].main,.62):(0,d.e$)(t.palette[e].main,.55)}`}},[`&.${y.checked} + .${y.track}`]:{backgroundColor:(t.vars||t).palette[e].main}}}))]}))),w=(0,p.Ay)("span",{name:"MuiSwitch",slot:"Track",overridesResolver:(t,e)=>e.track})((0,c.A)(({theme:t})=>({height:"100%",width:"100%",borderRadius:7,zIndex:-1,transition:t.transitions.create(["opacity","background-color"],{duration:t.transitions.duration.shortest}),backgroundColor:t.vars?t.vars.palette.common.onBackground:`${"light"===t.palette.mode?t.palette.common.black:t.palette.common.white}`,opacity:t.vars?t.vars.opacity.switchTrack:`${"light"===t.palette.mode?.38:.3}`}))),A=(0,p.Ay)("span",{name:"MuiSwitch",slot:"Thumb",overridesResolver:(t,e)=>e.thumb})((0,c.A)(({theme:t})=>({boxShadow:(t.vars||t).shadows[1],backgroundColor:"currentColor",width:20,height:20,borderRadius:"50%"}))),k=a.forwardRef(function(t,e){let r=(0,h.b)({props:t,name:"MuiSwitch"}),{className:a,color:i="primary",edge:d=!1,size:l="medium",sx:s,...n}=r,p={...r,color:i,edge:d,size:l},c=f(p),m=(0,x.jsx)(A,{className:c.thumb,ownerState:p});return(0,x.jsxs)(v,{className:(0,o.A)(c.root,a),sx:s,ownerState:p,children:[(0,x.jsx)(b,{type:"checkbox",icon:m,checkedIcon:m,ref:e,ownerState:p,...n,classes:{...c,root:c.switchBase}}),(0,x.jsx)(w,{className:c.track,ownerState:p})]})})},82092:(t,e,r)=>{r.d(e,{N0:()=>i,XO:()=>o,o7:()=>d,vL:()=>s,zM:()=>l});var a=r(11311);let o=async(t,e,r)=>{let o=new FormData;o.append("avatar",e);try{return(await a.n.put(`/profiles/${t}/avatar`,o,{headers:{Authorization:`Bearer ${r}`,"Content-Type":"multipart/form-data"}})).data}catch(t){throw console.error("Error uploading image:",t),t}},i=async(t,e,r)=>{let o=new FormData;o.append("logo",e);try{return(await a.n.post("/s3/upload/org/logo",o,{headers:{Authorization:`Bearer ${r}`,"Content-Type":"multipart/form-data"},params:{organizationId:t}})).data}catch(t){throw console.error("Error uploading image:",t),t}},d=async(t,e,r=[],o)=>{let i=new FormData;return i.append("media",e),await a.n.post("/s3/media/upload",i,{headers:{Authorization:`Bearer ${o}`,"Content-Type":"multipart/form-data"},params:{organization_id:t,addon_ids:r}})},l=async(t,e,r=[])=>{try{return(await a.n.get("/media/organization/"+t,{headers:{Authorization:`Bearer ${e}`,"Content-Type":"application/json"},params:{organizationId:t,addon_ids:r}})).data}catch(t){throw console.error("Error uploading image:",t),t}},s=async(t,e)=>a.n.delete("/s3/delete/img",{headers:{Authorization:`Bearer ${e}`},params:{fileKey:t}})},63354:(t,e,r)=>{r.d(e,{$3:()=>n,L9:()=>d,Wh:()=>s,Z_:()=>a,cH:()=>o,ll:()=>l});let a=["CONTENT","TABLE","IMAGE"],o=t=>/^https:\/\/pdf-crafter2\.s3\.us-east-1\.amazonaws\.com\/.+$/.test(t),i="https://media.istockphoto.com/id/1967543722/photo/the-city-of-london-skyline-at-night-united-kingdom.jpg?s=2048x2048&w=is&k=20&c=ZMquw-lP_vrSVoUlSWjuWIZHdVma7z4ju9pD1EkRPvs=",d=` <div style="font-family: Arial, sans-serif; line-height: 1.5; margin: 0; padding: 0; text-align: center;text-align: center; width: 100%; border-top: 1px solid #ccc;">
<div style="background-color: #f4f4f4; padding: 20px; ">
      <img
        src="${i}"
        alt="Logo"
        style="display: block; margin: 0 auto; max-width: 100px;"
      />
      <h1 style="margin: 10px 0;font-size: 20px; color: #555;">Company Name</h1>
      <p style="margin: 0; font-size: 14px; color: #555;">Your tagline or slogan here</p>
    </div> </div>`,l=`<div style="font-size: 10px; text-align: center; width: 100%;">
<div
      style="background-color: #f4f4f4; padding: 20px; text-align: center; font-size: 12px; color: #555;"
    >
      <p style="margin: 0;">123 Business Street, Business City, BC 12345</p>
      <p style="margin: 0;">
        Contact us: <a href="mailto:info@company.com" style="color: #007BFF;">info@company.com</a>
      </p>
      <p style="margin: 0;">&copy; 2024 Company Name. All rights reserved.</p>
    </div></div>`,s=`<div style="padding: 20px;">
      <h2 style="color: #333;">Welcome to Our Report</h2>
      <p style="margin: 0 0 10px; color: #555;">
        Below is a summary of our performance and goals. Feel free to review the details and let us know your thoughts.
      </p>

      <!-- Image Example -->
      <div style="text-align: center; margin: 20px 0;">
        <img
          src="${i}"
          alt="Sample Chart"
          style="max-width: 100%; height: auto;"
        />
      </div>

      <!-- Table Example -->
      <h3 style="color: #333;">Performance Overview</h3>
      <table
        style="width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 14px;"
      >
        <thead>
          <tr style="background-color: #f4f4f4;">
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Metric</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Target</th>
            <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Achieved</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Revenue</td>
            <td style="border: 1px solid #ddd; padding: 8px;">$1,000,000</td>
            <td style="border: 1px solid #ddd; padding: 8px;">$950,000</td>
          </tr>
          <tr style="background-color: #f9f9f9;">
            <td style="border: 1px solid #ddd; padding: 8px;">Customer Growth</td>
            <td style="border: 1px solid #ddd; padding: 8px;">20%</td>
            <td style="border: 1px solid #ddd; padding: 8px;">18%</td>
          </tr>
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">Satisfaction Score</td>
            <td style="border: 1px solid #ddd; padding: 8px;">90%</td>
            <td style="border: 1px solid #ddd; padding: 8px;">88%</td>
          </tr>
        </tbody>
      </table>
    </div>
`,n={initialColumns:3,initialRows:[{col1:"Data 1",col2:"Data 2",col3:"Data 3"}],initialStyles:Array.from({length:3},()=>({backgroundColor:"#f4f4f4",fontSize:"14",padding:"8px",color:"#000"})),customHtml:`<table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
                        <thead>
                            <tr style="background-color: #007bff; color: #ffffff;">
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Header 1</th>
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Header 2</th>
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Header 3</th>
                            </tr>
                        </thead><tbody></tbody></table>`}}};